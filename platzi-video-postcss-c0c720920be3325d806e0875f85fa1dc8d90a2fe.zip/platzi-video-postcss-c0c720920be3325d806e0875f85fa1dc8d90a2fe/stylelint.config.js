module.exports = {
  "rules": {
    "block-no-empty": true,
    "unit-whitelist": ["em", "rem", "%", "s", "fr", "vh", "dpi", "x"]
  }
}
